package com.scala.basics;

public class SwitchCase {

    public static void main(String a[])
        {
            String str = "two";
            switch(str)
            {
                case "one":
                    System.out.println("one");

                case "two":
                    System.out.println("two");

                case "three":
                    System.out.println("three");

                case "four":
                    System.out.println("three");

                default:
                    System.out.println("no match");
            }
        }

}
