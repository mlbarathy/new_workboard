package com.scala.basics

object ScalaVaribale extends App {

  var name="Suren"
  name="someother"
  println(name)
  lazy val varibale="suren"
  println(ScalaVaribale.varibale)
  var test:String=_
    println(test)
  val(x,y)=Pair("1","suren")

  println(x)
}
