package com.scala.basics

case class employee (name:String, age:Int)
object ScalaCaseClass
{
  // Main method
  def main(args: Array[String])
  {
    var a = employee("suren", 28)
    val b=employee("am",23)


    // Display both Parameter
    val cp=a.copy()
    val c1=a.copy(name="surendar")
    println("Name of the employee is " + a.name);
    println("Age of the employee is " + a.age);
    val caseList=List(a,b)
    for(x<-caseList){
      x match {
        case employee("suren",28) => println("haiiii")
        case employee("am",28) => println("haiiii")
        case  employee(name,age) => println("name "+name+ " age" +age)
      }
    }

  }
}