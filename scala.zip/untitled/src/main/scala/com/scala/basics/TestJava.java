package com.scala.basics;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class TestJava {


    static public Connection getCOnnection() {
        Connection con=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
             con= DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/sonoo", "root", "root");
//here sonoo is database name, root is username and password

        } catch (SQLException e) {
            System.out.println(e);
        }
        catch (NumberFormatException e) {
            System.out.println(e);
        }
        catch (ArithmeticException e) {
            System.out.println(e);
        }

        catch (ClassCastException e) {
            System.out.println(e);
        }

        catch (Exception e) {
            System.out.println(e);
        }


        finally {
            try {
                con.close();
            } catch (SQLException a) {
            }
        }
        return con;

    }


    public static void main(String a[])
    {
        List<String> al=new ArrayList<String>();
        Connection c1=TestJava.getCOnnection();
        TestJava obj=new TestJava();
        Connection c11=obj.getCOnnection();
        {
            try{
                Statement st= c1.createStatement();
                ResultSet rs=st.executeQuery("");
                Map m=new HashMap<String,String>();
                m.put("1","one");
                m.get("1");

            }
            catch (Exception e)
            {
                e.printStackTrace();
            }


        }
    }
}


