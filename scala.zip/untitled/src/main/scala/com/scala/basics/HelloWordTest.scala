package com.scala.basics

object HelloWordTest {

  val abc="dhfsd"
  def main(args: Array[String]): Unit = {

    println("Welcome to Scala")
/*
    val arg1=args(0)
    val arg2=args(1)
    println(arg1)
    println(arg2)
*/


   /* println(args.mkString(":"))*/
  }
}
