package com.scala.basics

object ScalaLazy {

  def main(args: Array[String]): Unit = {

    val nolazy={
    println("hello")
  }
    val a=10
    lazy val b=10

  lazy val lazyval={
    println("hello scala")
  }
    lazyval

  }
}
