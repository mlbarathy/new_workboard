package com.scala.basics;

public class HelloWord {
    //access_modifer class keyword classname
    public static void main(String arg[])

    {
        System.out.println("hellow");
    }
   String s="heloo";
}
