package com.scala.com.scala.com.scala.exception

object ScalaException {
  def main(args: Array[String]): Unit = {


    try {
      val a = 10
      a / 0
      println("sdvs")
    }
    catch {
      case e: ArithmeticException => println("Exception handled  " +e)

    }


    /*finally {
      println("finnaly blaock")
    }*/
    println("Sfs")


  }
}
