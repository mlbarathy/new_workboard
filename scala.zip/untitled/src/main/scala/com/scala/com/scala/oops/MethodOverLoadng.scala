package com.scala.com.scala.oops

object MethodOverLoadng {

  def main(args: Array[String]): Unit = {
    val obj1 = new A()
    val obj2 = new B()


    obj1.method1(10, 20)
    obj2.method1(10, 20)
  }
}

class A
{
  var a=0
  var b=0
  val test="a"
  var name=""
  def method1(a:Int,b:Int)
  {
    this.a=a
    this.b=b
    println(a*b)
  }

  def method1(a:Int,b:String)
  {
    this.a=a
    this.name=b
    println(a+b)
  }

}
class B extends A
{
  override val test="b"
  override def method1(x: Int, y: Int)
  {

    this.b=y;
    val a=x+b
    println(a)

  }
}
