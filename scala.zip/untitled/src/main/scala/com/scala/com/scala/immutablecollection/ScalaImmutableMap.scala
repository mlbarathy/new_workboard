package com.scala.com.scala.immutablecollection

object ScalaImmutableMap {
  def main(args: Array[String]): Unit = {
    var map:Map[String,String]=Map(("1","one"),("2","two"))
    val map1=map+("3"->"three")
    for((key,value)<-map1){
      println(key + " "+value)
    }

   // println(map)
  }

}
