package com.scala.com.scala.com.scala.Strings
package com.scala.function

object SrtingDemoScala {
  def main(args: Array[String]): Unit = {
    var s="hello welcome to scala "
    s=s+" lanugae"
   /* println(s.contains("welcome"))
    println(s.indexOf(""))*/
    val str11="hai"
    println(str11.compareToIgnoreCase("ha"))
    println(s.concat(" world"))
    var str=s.substring(s.indexOf("o"),s.lastIndexOf(" "))
   // println("str::::"+str)
    var a="gg"
 //   println(a.replace("a","aa"))

    var personalLoan = new String("HELLO");
    var homeLoan = new String("HELLO");

   // println(personalLoan==homeLoan)
    //println(personalLoan.equals(homeLoan))
  }
}
