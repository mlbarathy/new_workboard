package com.scala.com.scala.com.scala.Threads

class ThreadRunnable  extends Runnable{
  override def run(){

    for(a <- 0 to 3) {
      println("Thread is running..." +"Name "+Thread.currentThread().getName+ " " +a);
      Thread.sleep(5000)
     // println("final steps")

      task()
    }

  }
  def task(): Unit =
  {
    for(i<- 0 to 5){
      println( Thread.currentThread().getName+ " Thread task method "+i)
      Thread.sleep(500)
    }
  }
}
object ThreadRunnableDemo{
  def main(args:Array[String]){
    var t = new ThreadRunnable()
    var t1=new ThreadRunnable
    var thrdobj=new Thread(t)
    var thrdobj1=new Thread(t)
    thrdobj.start()
    //t.join()
    thrdobj1.start()

  }
}
