package com.scala.com.scala.oops;

public class JavaConstructor {
    public String name="";
    int age=10;
    public JavaConstructor(String name,int age)
    {

        this.name=name;
        this.age=age;
    }

    public static void main(String arg[])
    {
        System.out.println("sfs");
        JavaConstructor obj=new JavaConstructor("suren",27);


    }
}
