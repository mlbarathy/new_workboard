package com.scala.com.scala.mutablecollection

object ScalaMutableListBuffer {
  def main(args: Array[String]): Unit = {
    val listbuffer=scala.collection.mutable.ListBuffer[String]("one","two")
    listbuffer+="three"

    listbuffer++=List("10","20")
  }

}
