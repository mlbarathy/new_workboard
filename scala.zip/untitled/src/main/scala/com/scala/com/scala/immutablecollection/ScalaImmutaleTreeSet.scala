package com.scala.com.scala.immutablecollection

import scala.collection.immutable.{SortedSet, TreeSet}

object ScalaImmutaleTreeSet {
  def main(args: Array[String]): Unit = {
    val treeset :TreeSet[String]=TreeSet("5","2","1","3")
    println(treeset)


    val treeset1 :SortedSet[String]=SortedSet("5","2","1","3")
    println(treeset1)
  }

}
