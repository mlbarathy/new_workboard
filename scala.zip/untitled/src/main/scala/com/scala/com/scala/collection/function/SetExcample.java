package com.scala.com.scala.collection.function;

import java.util.*;

public class SetExcample {
    public static  void main(String a[]) {
        HashSet set1 = new HashSet();
        HashSet h1=new HashSet();
        h1.add(10);
        h1.add(20);
        set1.add(5);
        set1.add(10);
        set1.add(15);
        System.out.println(set1);
        set1.add("hello");
        set1.add(h1);
        List l=new ArrayList();
        l.add(5);
        HashMap m=new HashMap<>();

        System.out.println(set1.getClass());
       // Class<?> type = obj.getClass();
      //  while (type.isArray()) {
          Class<?> type = l.getClass();
          System.out.println(type);

    }
}
