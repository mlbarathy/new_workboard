package com.scala.com.scala.oops

trait Print{
  def printout()
}

trait ColorPrint{
  def printout()

}

abstract class PrintA4{
  def printA4()
}

class A6 extends Thread with ColorPrint  {
  override def printout(){                             // Trait print
    println("print sheet")
  }
  def printA4(){                              // Abstract class printA4
    println("Print A4 Sheet")
  }
  def colorSheet(){                              // Abstract class printA4
    println("Color print Sheet")
  }
}

object TraitsDemo{
  def main(args:Array[String]){
    var a = new A6()          // You can also extend trait during object creation
    //a.printout()
    a.printA4()
  }
}
