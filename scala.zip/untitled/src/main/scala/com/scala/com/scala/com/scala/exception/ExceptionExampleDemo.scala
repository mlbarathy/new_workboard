package com.scala.com.scala.com.scala.exception

import java.io.{FileNotFoundException, FileReader}

object ExceptionExampleDemo {

  def main(args: Array[String]): Unit = {

    try {


     new ExceptionExample().validate(10)
      println("try will continue ")
    }
    catch {
      case nf :NumberFormatException=>println("Exception handled"+nf.getMessage)
      case ar :ArrayIndexOutOfBoundsException=>println("ArrayIndexOutofBound Exception Here"+ar)
      case e :Exception=>println(" Exception Here "+e.getMessage())
        try{
          new ExceptionExample().ArithmeticOperation(100,0)
        }
        catch {
          case e: Exception => println(" Exception Here " + e.getMessage())
        }
      // System.exit(1)

    }
    println("Exeution continued")

  }
}
class ExceptionExample{
  @throws(classOf[NumberFormatException])
  @throws(classOf[FileNotFoundException])
  def ArithmeticOperation(a:Int,b:Int): Unit =
  {
      a/b
     println("code will continue")
  }
  def FileReaderMethd: Unit ={

    try{
      val file=new FileReader("c:\test")
    }
    catch
      {
        case fn:FileNotFoundException=>println("FileNot found" +fn.printStackTrace())
        case e:Exception=>println("FileNot found" +e.printStackTrace())
      }
    println("after try oode")
  }
  def validate(a:Int)  = {


    /*//"haii".toInt
    var name=null
    name.toString

*/
    if(a<18)
      {
        throw new ArithmeticException("not eligile")
      }

  }
}



/*
1)	Java throw keyword is used to explicitly throw an exception.	Java throws keyword is used to declare an exception.
2)	Checked exception cannot be propagated using throw only.	Checked exception can be propagated with throws.
3)	Throw is followed by an instance.	Throws is followed by class.
4)	Throw is used within the method.	Throws is used with the method signature.
5)	You cannot throw multiple exceptions.	You can declare multiple exceptions e.g.
public void method()throws IOException,SQLException.
*/
