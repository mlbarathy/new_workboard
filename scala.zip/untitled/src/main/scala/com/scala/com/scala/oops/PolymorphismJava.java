package com.scala.com.scala.oops;

public class PolymorphismJava {
    public static void main(String a[])
    {
        a obj=new a();
        obj.test();
        a obj1=new x(); //runtime polymoprsim
        obj1.test();

        x obj4=new x();
        obj4.test();
        obj.test("dfdd"); //compile time polymorphism


    }
}
class a
{
    public void test()
    {
        System.out.println("a class calling");
    }

    public void test(String s)
    {
        System.out.println("overloading"+s);
    }
}
class x extends a
{
    public void test()
    {
        System.out.println("x class caling");
    }
}
