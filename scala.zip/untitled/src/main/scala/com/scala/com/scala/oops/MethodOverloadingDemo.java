package com.scala.com.scala.oops;

import java.util.ArrayList;

public class MethodOverloadingDemo {
    public static void main(String a[])
    {
        test t=new test();
        ArrayList al=new ArrayList();
        al.add(10);
        al.add(20);
        al.add(0,"hai");


        t.m1();
        test t1=new test1();
        System.out.println(t1.text);
        t1.m2("ha");
        test1 t11=new test1();
        t11.m1();

    }
}
class test
{
    String a="10";
    /*public test( String a,String b)
    {

    }*/
    public String text="suren";
    public void m1()
    {
        System.out.println("test class method");
    }
    public void m2(String s)
    {
        System.out.println("method overloading:"+s);
    }
}
class test1 extends test
{

    public void m1()
    {
        System.out.println("test1 class method"+a);
    }



}
