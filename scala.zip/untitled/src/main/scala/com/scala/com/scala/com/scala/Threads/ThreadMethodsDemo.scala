package com.scala.com.scala.com.scala.Threads

class ThreadMethods extends Thread{
  override def run(){
    for(i<- 0 to 5){
     // println("Thread run method " +i)
      println(this.getName()+" - "+i+" - "+this.getPriority())

      //Thread.sleep(500)
    }
  }
  def task(): Unit =
  {
    for(i<- 0 to 5){
      println("Thread task method "+1)
      Thread.sleep(500)
    }
  }
}
object ThreadMethodsDemo
{
  def main(args: Array[String]): Unit = {
    var t1 = new ThreadMethods()
    var t2 = new ThreadMethods()
    var t3 = new ThreadMethods()
    t1.setName("First Thread")
    t2.setName("Second Thread")
    t1.setPriority(Thread.MIN_PRIORITY) //1
    t3.setPriority(Thread.MIN_PRIORITY) //5
    t2.setPriority(Thread.MAX_PRIORITY) //10
    t1.start()
    //t1.join()
    t2.start()
  }
}
