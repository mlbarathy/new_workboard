package com.scala.com.scala.mutablecollection

object ScalaMutableLinkedHashMap {
  def main(args: Array[String]): Unit = {
    val linkedHashMap=scala.collection.mutable.LinkedHashMap(("2","two"),("1","one"))
    println(linkedHashMap)
    val treeset=scala.collection.mutable.TreeSet("2","1")
    println(treeset)
  }

}
