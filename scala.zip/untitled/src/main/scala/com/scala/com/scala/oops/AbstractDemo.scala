package com.scala.com.scala.oops

object AbstractDemo {

  def main(args: Array[String]): Unit = {

    var name="suren"
    var amount=10000
    var loanType="home"
    var bankName="Hdfc"

     var hdfc=new HDFC()

     hdfc.withdraw(name,amount)
    hdfc.optionalMethod(10)
    var axis=new Axis;
    axis.deposite(name,amount)
    if(bankName.equalsIgnoreCase("Hdfc")) {
      val result = hdfc.CalCulateIntrest(bankName, loanType, amount)
      println(s"Interest rate is : $result ")
    }
  }

}
abstract class Bank
{
  def deposite(username :String,amount:Int)
  def withdraw(username:String,amount:Int)
  def CalCulateIntrest(bankName:String,loanType:String,loanAmout:Long):AnyVal
  def optionalMethod(param:Int) =
  {
    println("implemented here")

  }
}
