package com.scala.com.scala.oops

class ScalaClassScope {
  val str = "str_ale"

  def test() = {
    println("hai")
  }
}
class b
{
  def test1(): Unit =
  {
    println("sjdfhsjfh")
  }
  def main(args: Array[String]): Unit = {

  }
}

  object ScalaClassScopeDemo {
    def test1(): Unit =
    {
      println("sjdfhsjfh")
    }
    def main(args: Array[String]): Unit = {
      val obj = new ScalaClassScope
      val obj1=new b

      println(obj.test())
      println(test1())
      println(obj.str)
    }
  }

