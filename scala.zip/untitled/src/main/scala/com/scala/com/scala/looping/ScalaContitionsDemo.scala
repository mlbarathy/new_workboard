package com.scala.com.scala.looping

object ScalaContitionsDemo {


  def main(args: Array[String]): Unit = {
    val odds = List(1, 3, "a", 5, 7, 9)
   for(a<- odds.length to 0 by -1)
      {
        println(a)
      }

    /*var word = "welcome to scala"
    var a: Int = 5
    while (a <= 5) //while(true)
    {
      println("looping count" + a)
      //a=a+1
      a = 1


    }

    do {
      a = a + 1
      println("do whille stared" + a)
    }
    while (a < 10)
    var i = 0

*/
    /*for (i <- 5 to 10) {

      println(i)
    }

    for (i <- 5 until 10) {

      println(i)
    }
    for (a <- 1 to 10 if a % 2 == 0) {
      println(a);
    }*/

   /* for(x<-1 until 3;y<-7 to 9)
    {
      println(x +" "+y)
    }*/
/*
    val listval = List(1, 3, "a", 5, 7, 9)
    for (a <- 2 to listval.length) {
      println(a)
    }
*/


    val odds1 = List(1, 3, 5, 7, 9, 11, 13, 15, 17, 19)
    var ret = for {a <- odds1
                   if a > 3 && a < 15} yield {
      a * a
    }
    println(ret)

  }
}
