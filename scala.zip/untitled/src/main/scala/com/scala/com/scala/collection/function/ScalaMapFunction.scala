package com.scala.com.scala.collection.function

object ScalaMapFunction {
  def main(args: Array[String]): Unit = {
    //def map[B](f: [A] ⇒ B): Traversable[B]
    var seq=List(1,2,3,5,7,10)
    val mymap=Map(1->"one",2->"two")
   val b= seq.map(x=>{
     (x,x *2)

   })
    println(b)
    val x=mymap.map(x=>"hi"+x)
    println(x)
    val y=mymap.mapValues(x=>"hi"+x)
    println(y)
    println("hello".map(x=>x.toUpper))
    val list=List(List(1,2,3),List(5,6,7))
    println(list.flatten)

    seq.sum
    val flatmap=seq.flatMap(
      x=>
      {(x+"2")
      }
    )
    println("FltMap:"+flatmap)
    var seq1=Seq("1","2","3")
    val filtr=seq1.filter(x=>
    {
      x.contains("1")|| x.contains("2")
    })
    println(filtr)
//    println("sjdfhsh" +seq1.head(2))




  }

}
