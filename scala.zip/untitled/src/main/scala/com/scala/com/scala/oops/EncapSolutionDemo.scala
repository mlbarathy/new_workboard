package com.scala.com.scala.oops

class c(private  var name:String, var age:Int)
{
  def getName{
    println(name)
  }
  def setName(name:String)
    {
      this.name=name;
  }
}
object EncapSolutionDemo {
  def main(args: Array[String]): Unit = {
    val obj=new c("suren",28)
    println(obj.age)
    obj.age=30
    obj.getName

    obj.setName("surendar")
    obj.getName

  }

}
