package com.scala.com.scala.immutablecollection

import scala.collection.immutable.{ListMap, ListSet}
import scala.collection.mutable

object ScalaImmutableListSet {
  def main(args: Array[String]): Unit = {
    var listSet1:ListSet[Any]=ListSet("one","two",2)
    val listSetAdd=listSet1+"one"

    println(listSetAdd)
    val twoListSet=listSet1++listSetAdd
    val removeListset=listSet1-("three")
    val listMap1=ListMap(1->"one",2->"two")
    val listMap1Add=listMap1+(3->"three")

  }

}
