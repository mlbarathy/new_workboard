package com.scala.com.scala.mutablecollection

import java.util.Map


object ScalaMutableMap {
  def main(args: Array[String]): Unit = {
    val map=scala.collection.mutable.Map[String,String](("1","one"),("2","two"))
    map +=(("3","three"))
    val map1=scala.collection.mutable.Map[String,String](("1","one"),("2","two"))

    map1 +=(("3"->"three"))
    map1++=map
    println(map.contains("1"))


  }

}
