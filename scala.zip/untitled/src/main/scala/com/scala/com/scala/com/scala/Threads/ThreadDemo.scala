package com.scala.com.scala.com.scala.Threads

class ThreadExample extends Thread{
  override def run(){

    for(a <- 0 to 1) {
      println("Thread is running..." +"Name "+this.getName+ " " +a);
      Thread.sleep(5000)

     // println("final steps")

      task()
    }

  }
  def task(): Unit =
  {
    for(i<- 0 to 1){
      println("Thread name "+this.getName+  " task method "+i)
      Thread.sleep(500)
    }
  }
}
object ThreadDemo{
  def main(args:Array[String]){
    var t = new ThreadExample
    var t1=new ThreadExample
    t.setName("Thread1")
    t1.setName("Thread2")
    t.start()
    t.join()
    t1.start()

  }
}
