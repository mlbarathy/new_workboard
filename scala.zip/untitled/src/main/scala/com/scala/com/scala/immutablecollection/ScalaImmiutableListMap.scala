package com.scala.com.scala.immutablecollection

import scala.collection.immutable.ListMap

object ScalaImmiutableListMap {
  def main(args: Array[String]): Unit = {
    val listMap1:ListMap[String,String]=ListMap("1"->"one","2"->"two")
    val listMap2=listMap1+("3"->"three")
    val addListMap=listMap1++listMap2
    val removeListMap=listMap1-("2")
    val emptyListMap:ListMap[String,String]=ListMap.empty[String,String]
    val listMap11:ListMap[String,String]=ListMap(("1","one"),("2","two"))
    //println(listMap11)
    for((key,value)<-listMap11){ println(key + " "+value)}
    listMap1.foreach(x=>{
      println(x._1 + " value "+x._2)
    })

    listMap1.foreach{
      case(movie, rating) => println(s"key: $movie, value: $rating")
  }
    listMap1.keys.foreach((movie) => println(movie))
    listMap1.keys.foreach(println)



  }

}
