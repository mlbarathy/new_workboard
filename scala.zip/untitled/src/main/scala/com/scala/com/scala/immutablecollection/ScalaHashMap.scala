package com.scala.com.scala.immutablecollection

import scala.collection.immutable.TreeMap

object ScalaHashMap {
  def main(args: Array[String]): Unit = {
    val map:TreeMap[String,String]=TreeMap(("5","one"),("2","two"))
    val map1=map+("3"->"three")
    for((key,value)<-map1){
      println(key + " "+value)
    }
  }


}
