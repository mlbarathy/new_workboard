package com.scala.com.scala.collection.function

import com.scala.basics.HelloWordTest

object ScalaCollectionMethod {

  case class product(item:String,price:Int)
  val p1=product("phone",10000)
  val p2=product("phone",1500)
  val p3=product("phone",5000)
  val lst:Seq[product]=Seq(p1,p2,p3)

  //println(lst.sortBy(product=>product.price))
  val reduceSeq: Seq[Int] = Seq(1, 2, 3,5,7)
  val result=reduceSeq.reduce((x,y)=>
  //{
   // println(x+"  "+y);
    x+y
  //}
  )
  println(result)

 /* println(reduceSeq.reduceLeft((x,y)=> {
    println(x+"  "+y)
    x+y;
  }))*/
 /* println(reduceSeq.reduceRight((x,y)=> {println(x+"  "+y);
      x+y;}))*/

  /*println(reduceSeq.foldLeft(10)((x,y)=> {println(x+"  "+y)
        ;x+y;}))


 println(reduceSeq.scanLeft(10)((x,y)=> {println(x+"  "+y);
          x+y;}))*/
/*  println(reduceSeq.scanRight(10)((x,y)=> {println(x+"  "+y);

    x+y}))

*/
  def main(args: Array[String]): Unit = {
    var seq1=Seq("1","2","3")
    val find=seq1.find(_=="5").getOrElse("default")
    println(find)
    val seqlist: Seq[String] = Seq.empty[String]
    println(seqlist.headOption.getOrElse("defualt"))
    println(seq1.lastOption.getOrElse("dummy"))

  }

}
