package com.scala.com.scala.oops

import com.scala.function.ScalaNestedFunction

class Car {

  var size=0
  var color=""
  var brand=""
  def setSize(size:Int)
  {
    this.size=size
  }

  def setColor(color:String)
  {
    this.color=color
  }
  def setBrand(brand:String)
  {
    this.brand=brand
  }

}
object ScalaClassExampleDemo
{
  def main(args: Array[String]): Unit = {
    val obj1=new Car
    println(obj1.brand)
    obj1.setSize(10)
    obj1.setColor("red")
    obj1.setBrand("bmw")

  }
}
