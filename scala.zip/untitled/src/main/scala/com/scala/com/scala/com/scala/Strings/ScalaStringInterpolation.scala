package com.scala.com.scala.com.scala.Strings

object ScalaStringInterpolation {
  def main(arg:Array[String])
  {
    val name="Scala"
    println(name +" is efective programming launvgage")
    println(s"Welcome 2  $name language")
    val version=2.12






















    println(f"welcome to scala version is $version%2.2f")
    println(s"Scala\tstring \nexample")
    println(raw"Scala \tstring \nexample")

  }


}
