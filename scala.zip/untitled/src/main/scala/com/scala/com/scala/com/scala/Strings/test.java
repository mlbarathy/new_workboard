package com.scala.com.scala.com.scala.Strings;

public class test {

    public String test111()
    {
        System.out.println("sdfsddsds");
        return "hgdjh";
    }
    public static void main(String a[])
    {
        StringBuffer s=new StringBuffer("hai");
        String s1 = new String("HELLO");
        String s2 = new String("HELLO");
        System.out.println(s1 == s2);
        System.out.println(s1.equals(s2));

       /* for(int i=0;i<4; i++)
        {
            System.out.println(i);
            for(int j=0;j<i;j++)
            {
                System.out.print(j);
            }

        }

*/
    }
}
