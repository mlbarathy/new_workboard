package com.scala.com.scala.looping

object ScalaBranchDemo {
  def main(args: Array[String]): Unit = {
    var age:Int = 20;
    if(age > 18){
      println ("Age is greate than 18")
    }
    else
      {

      }
    var number:Int = 21
    if(number%2==0){
      println("Even number")
    }else{
      println("Odd number")
    }
  }

}
