package com.scala.com.scala.oops

class Student( val id:Int, val name:String){
  var age:Int=0
  def showDetails(){
    println(id+" "+name);
  }
  /*def this(id:Int, name:String,age:Int){
       // Calling primary constructor, and it is first line
    this(id,name)
    this.age = age
    println(age)
    println(id)
  }*/
}
object ScalaConstrDemo {
  def main(args: Array[String]): Unit = {
    var s = new Student(101,"suren");
    s.showDetails()
  }

}
