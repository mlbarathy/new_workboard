package com.scala.com.scala.oops

class HDFC extends Bank
{
  override def deposite(username :String,amount:Int): Unit =
  {
    if(username.equalsIgnoreCase("suren"))
    {
      println("Validation done and you can deposite the amount in hdfc")
    }
  }

  override def withdraw(username: String, amount: Int): Unit =
  {
    if(username.equalsIgnoreCase("suren"))
    {
      println("Validation done and you can withdraw amount in hdfc")
    }
  }

  override def CalCulateIntrest(bankName: String, loanType: String, loanAmout: Long):AnyVal=
  {

    if(loanType.equalsIgnoreCase("home"))
    {
      println("Interest calclualtin implementaion here")
      var result=loanAmout*10/100
      result
    }
  }
}
