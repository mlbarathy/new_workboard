package com.scala.com.scala.immutablecollection

import scala.collection.immutable.ListSet


object ScalaImmutableListDemo {
  def main(args:Array[String]): Unit = {
    //val emptyList=List.empty[String]
    val list:List[Any] = List("1", "2","hello",1,'c',false,3.0)

      val list1=list:+"3"
    println(list.contains("hello"))

    val list3:List[Any]=list
    val emtyList:List[String]=List.empty[String]
    println(list3(3))
    var listset1:ListSet[String]=ListSet("1","2")
    //val istb=ListBuffer import scala.collection.mutable.ListBuffer()
    val listset2=listset1+ "3"
    val listset3=listset1 ++ listset2
   // println(listset3)
    list3.foreach(x=>{
      val a=x
      if(x.equals("hello"))
        {

        }

    })
  }
}
