package com.scala.com.scala.immutablecollection

import scala.collection.immutable.HashSet

object ScalaImmutableSetDemo {
  def main(args: Array[String]): Unit = {
    var set1:HashSet[String]=HashSet()
    var set2=Set(1,"hai",1.00,false)
    set1+="one"

    set1-="1"

    for(x<-set1)
      {
        println(x)
      }
    set1.foreach(x=>println(x))
    val mergeset=set1++set2
  }

}
