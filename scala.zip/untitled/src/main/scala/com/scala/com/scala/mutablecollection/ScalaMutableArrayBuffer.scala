package com.scala.com.scala.mutablecollection



object ScalaMutableArrayBuffer {
  def main(args: Array[String]): Unit = {
    var arrayBuffer=scala.collection.mutable.ArrayBuffer[String]("one","two")
    arrayBuffer+="three"
    arrayBuffer++=List[String]("four","five")
    //arrayBuffer-="four"
    println(arrayBuffer)

  }

}
