package com.scala.Arrays

object TupleDemo {
  def tupleFunction()={
    var tuple = (1,2.5,"India")
    tuple
  }
  def main(args: Array[String]): Unit = {


    val t1 = (1, 2.0f,2.0, "dfg", true)
    val t2=(1,2,("hai","hell"))
    println(t2._2)
    t1.productIterator.foreach(println)
    println(1->"first"->"second")
   // var tupleValues = tupleFunction()
   // println(tupleValues)
  }

}
