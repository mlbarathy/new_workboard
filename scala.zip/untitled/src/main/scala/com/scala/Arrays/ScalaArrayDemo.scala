/*
package com.scala.Arrays
import Array._

object ScalaArrayDemo {
  def main(args: Array[String]): Unit = {
    val arrayTest = new Array[String](3)
    val arry: Array[Any] = new Array[Any](2)
    arry(0) = 1
    arry(1) = "df"
    arrayTest(0) = "10"
    arrayTest(1) = "scala"
    arrayTest(2) = "scala lanugae"


    println(arrayTest.toList)
    val conarry = concat(arrayTest, arry)
      var arryval = Array[Any](1, 2, 3, 4)
    for (x <- 0 to arrayTest.length - 1) {
      println(arrayTest(x))
    }
    for (x <- arrayTest) {
      println(x)
    }
    var arr = Array.ofDim[Int](2, 2)
    arr(0)(0) = 10
    arr(1)(0) = 10
    for (a <- 0 to 1) {
    for (b <- 0 to 1) {
      print(" "+arr(a)(b))
    }
      println()
  }

  }

}
*/
