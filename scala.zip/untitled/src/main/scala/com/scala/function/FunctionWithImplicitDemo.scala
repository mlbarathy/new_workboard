package com.scala.function

object FunctionWithImplicit
{
  def cost(item:String, qunatity:Int)( implicit discount:Int,name:String): Double =
  {
    println(discount)

    var totCost=qunatity*discount/100;
    totCost
  }
}
object FunctionWithImplicitDemo {
def main(args:Array[String]): Unit = {
  implicit val discount=10
  implicit var name="defaultval"
  val result = FunctionWithImplicit.cost("item", 1)
  println(result)


}
}
