package com.scala.function

//If you are applying values partially for function is called partially applied function.
object ScalaPartialImplMethod {
  //val username=(username:String,domain:String)=>username+domain

  def username=(username:String,domain:String)=>/*s"$username$domain"*/ username+domain
  def test(): String =
  {
    "@gmail.com"
  }

  //def email=username(_:String,test())
  def email=username(_:String,"@gmail.com")

  def main(args: Array[String]): Unit = {
      val inputname="suren"
    if(!inputname.contains(".com")) {
      val result=email(inputname)
      println(result)
    }
  }
}
