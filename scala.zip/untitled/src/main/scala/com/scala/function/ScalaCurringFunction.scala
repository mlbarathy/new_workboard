package com.scala.function
//Currying functon is all about multi parameter. we have not necessary
// to provide the implementation at the time of calling later on you can provide or at run time
//you can provide the implementation
object ScalaCurringFunction {

  //def function name(argument1) (argument2) = operation
  def add(a:Int)(b:Int=10):Int={
    a+b
  }
  //Another way to declare currying function
    //Suppose, we have to transform this add function into a Curried function,
  // that is transforming the function that takes two(multiple) arguments
  // into a function that takes one(single) argument.
    //def function name(argument1) = (argument2) => operation
    def add2(a: Int) = (b: Int) => a + b;

  def main(args: Array[String]): Unit = {
   println(add(10)(30))
    println(add2(20)(19));
    val intermdeiate=add(50)_
    val result=intermdeiate(30)
    //println(result)
    val partial=add2(50)
    val partialresult=partial(30)
   // println(partialresult)
  }

}
