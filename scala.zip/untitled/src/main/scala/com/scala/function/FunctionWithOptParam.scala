package com.scala.function

class FunctionWithOptParam {

  def func(name:String,quantity:Int,code:Option[String]=None):Double={

    var pricecol=quantity*100
    code match{
      case Some(code)=>
        val discount=10
        pricecol=quantity*100
        val tot=pricecol-(pricecol*discount/100)
        tot
      case none=>pricecol
    }
  }

  def func1(name:String,quantity:Int,code:String):Double={
    var pricecol=quantity*100
    code match{
      case "ds"=>
        val discount=10
        pricecol=quantity*100
        val tot=pricecol-(pricecol*discount/100)
        tot
      case none=>pricecol
    }
  }

}
object FunctionWithOptParamDemo{
  def main(args:Array[String]): Unit =
  {
   println(s"${new FunctionWithOptParam().func("dount",5,Some("ds"))}")
    println(s"${new FunctionWithOptParam().func("dount",10,Some("dd"))}")
    println(s"${new FunctionWithOptParam().func("dount",quantity = 15,Some("dddd"))}")
    println(s"${new FunctionWithOptParam().func("dount",5)}")
    //println(s"${new FunctionWithOptParam().func1("dount",5,"dd")}")

  }
}
