package com.scala.function
object ScalaTypedFun
{
  def TypeFunction[T](typeVal:T) =
  {
    typeVal match {
      case value:String =>
        typeVal
      case d:Int=>
        typeVal
      case _ =>
        typeVal
    }
  }
}

object ScalaTypedFunctionDemo {
  def main(args: Array[String]): Unit = {
   val result=   ScalaTypedFun.TypeFunction(10)
    println(result)
  }

}
