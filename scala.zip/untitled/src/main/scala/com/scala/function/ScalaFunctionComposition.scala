package com.scala.function

object ScalaFunctionComposition {

  def addfunction(a:Int):Int =
  {
    a+2
  }
  def multifunction(a:Int):Int=
  {
    a*2
  }

  def main(args: Array[String]): Unit = {
    println(multifunction(addfunction(10)))
    /*val result=addfunction((10))
    val result1=multifunction(result)*/
  }
}
