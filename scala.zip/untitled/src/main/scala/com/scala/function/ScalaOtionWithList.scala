package com.scala.function

object ScalaOtionWithList {
  def main(ag:Array[String]) {
    val list = List(1, 2, 3,5)
    val map = Map(1 -> "tom", 2 -> "max", 3 -> "john")
    println(list.find(_ > 2)/*getOrElse("no val")*/);
   // println(map.get(2).getOrElse("no value"));
  }
}
