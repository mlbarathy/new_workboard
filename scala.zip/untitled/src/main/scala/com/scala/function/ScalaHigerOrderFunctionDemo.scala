package com.scala.function

//A function is called Higher Order Function if it contains other functions as a parameter or returns a function as an output i.e, the functions
// that operate with another functions are known as Higher order Functions.
object ScalaHigerOrderFunctionDemo {
                //10  //callingFunction
  def function1(a:Int,userfun:Int =>AnyVal) =
  {
    println("fs")
    println(userfun(a)) //callingFunction(10)
   /* val result=userfun(a)
    println()
*/
  }
def callingFunction(x:Int): Int =
  {

    x*2   //10*2
  }

  def main(args: Array[String]): Unit = {
    println("started")
   function1(10,callingFunction)
    val test="welcome"
  }
}
