package com.scala.function

object ScalaNamedParamFucntion {
  def nameParamMethod(a:Int,b:String){
   // val c=a-b;
    //c
  }

  def defaultParam(a:Int=10,b:Int=20):Int={
    val c=a-b;
    c
  }

  def main(args: Array[String]): Unit = {
    val result=nameParamMethod(10,"test")
    println(result)
    val result1=nameParamMethod(b="100",a=1)
    println(result1)
    println(defaultParam())
  }
}
