package com.scala.function
//n Scala, An anonymous function is also known as a function literal. A function which does not contain a name is known as an anonymous function. An anonymous function provides a lightweight function definition.
//It is useful when we want to create an inline function.
//In the above first syntax, => is known as a transformer. The transformer is used to transform the parameter-list of the left-hand side of the symbol into a new result using the expression present on the right-hand side.
//In the above second syntax, _ character is known as a wildcard is a shorthand way to represent a parameter who appears only once in the anonymous function.
object ScalaAnonymousFunction {
  def main(args: Array[String]): Unit = {
    val resulet=(a:Int,b:Int) =>a+b //(a,b)=>a+b)
    val result1=(_:Int)+(_:Int)     //(_+_)
    println(resulet(10,10))
    println(result1)
  }
}
