package com.scala.function
class ScalaFunctionWithNo
{
  def function1():String= {
"Hello"
}
  def function2()= "Scala world"

  def function3():Unit={
    "welcome to scala"
  }
}
object ScalaFunctionWithNoParam {
  def main(args: Array[String]) {
    val obj=new ScalaFunctionWithNo()

    val result=new ScalaFunctionWithNo().function1()
    val result1=new ScalaFunctionWithNo().function2()

    println(result)
    println(result1)
    println(new ScalaFunctionWithNo().function3())


  }
}