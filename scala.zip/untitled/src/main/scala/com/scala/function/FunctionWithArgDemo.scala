package com.scala.function

import com.scala.com.scala.com.scala.Strings.test

class FunctionWithArgDemo{

  def emp(name:String="ss",age:Int=10) =
  {
      name
  }
}
object FunctionWithArgDemo {
  def emp(name:String="ssss",age:Int=10) =
  {
    name
  }
  def main(args:Array[String]) {
    val empname = new FunctionWithArgDemo().emp()
    val obj1=new test()
    val javamethod=obj1.test111()
    println(javamethod)
    val output=FunctionWithArgDemo.emp("suren",100)
    println(empname)
  }
}
