package com.scala.function

import com.scala.com.scala.oops.{ScalaClassScopeDemo, b}

//If you want to create sub function within function that is releavent to particular main function
// and calling the sub sunction within the main function
object ScalaNestedFunction {

  def add(a:Int, b:Int, c:Int) = {
    println("root function started")

    def add2(x:Int,y:Int) = {
      x+y
    }
    println("sub function calling")
    add2(a,add2(b,c))
  }

  def main(args: Array[String]) = {
    println("Started program")
    var result = add(10,10,10)
    println(result)
    val obj=new b
    obj.test1()
    val outut=ScalaClassScopeDemo.test1()
  }

}
