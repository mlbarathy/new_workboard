package com.scala.function

object ScalaPatternMatch {

  val patternCheck="hello"
  patternCheck match{
    case "hello" => {
      val i = 20;
      println(i)
    }
    case _ =>{
      println("defualt")
    }
  }

  def patternMatch(x:Any):Any=x match {
    case "1" =>{ val l=List(1,2,3)
      l}
    case "2" => {}
    case x:Int=> "Perform integer operations"
    case _ => {"place holder"}
  }
  val i=7
  i match{
    case 1 |3 | 5 |   7=>println("add")
  }
  def main (args: Array[String] ): Unit = {

    println(patternMatch("1"))
    println(patternMatch(1))
    println(patternMatch(199))


  }
}


